# ellipsis

## Running a test instance
Use Docker to build/run a local instance:

```bash
docker build -t ellipsis .
docker run --privileged -it -p 1337:1337 ellipsis
```

Then, navigate to https://127.0.0.1:1337.
