#!/bin/bash

python3 /web-apps/python/server.py
